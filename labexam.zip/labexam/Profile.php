
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table border="1" >
		<tr>
			<th>ID</th>
			<td>16-10101-2</td>
	</tr>
	<tr>
		<th> Name</th>
		<td>Bob</td>
	</tr>
	<tr>
		<th rowspan="3"> USER type</th>
		<td>Admin</td>
	</tr>
	</table>

</body>
</html>