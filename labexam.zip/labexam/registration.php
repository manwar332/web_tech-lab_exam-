<!DOCTYPE html>
<html>
<head>
	<title>REGISTRATION</title>
</head>
<body>
	<form>

		<fieldset style="height: 500px; width: 300px; background-color: gray;">
			<legend >REGISTRATION</legend>
			id <br>
			<input type="text" name="id"> <br>
			password <br>
			<input type="password" name="password"> <br>
			 Confirm-Password <br>
			<input type="password" name="cpassword"> <br>
			Name <br>
			<input type="text" name="id"> <br>
			User Type <br>
			<input type="radio" name="radio"> Users <input type="radio" name="radio"> Admin <br>
			<input type="submit" name="Sign Up"> <a href="signIn"> Sign In</a>

		</fieldset>
	</form>

</body>
</html>