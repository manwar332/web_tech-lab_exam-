<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
</head>
<body>
	<form method="post" action = "login.php">
		<table>
			<tr>
				<th colspan="2"><h2 align="center">LOGIN</h2></th>
			</tr>
			<tr>
				<td>Username : </td>
				<td><input type="text" name="email"></td>
				

				
			</tr>
			<tr>
				<td>Password : </td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr>
				<td align="right" colspan="2"><input type="submit" name="login" value="login"></td>
			</tr>


		</table>
	</form>









	


</body>
</html>