








<!DOCTYPE html>
<html>
<head>
	<title>CHANGE PASSWORD</title>
</head>
<body>
	<form>
		<fieldset>
			<legend>CHANGE PASSWORD</legend>
			Current Password <br>
			<input type="password" name="password">
			New Password <br>
			<input type="password" name="password">
			Retype New Password <br>
			<input type="password" name="password"> <br>
			<input type="submit" name="Change"> <a href="success.php"></a>
		</fieldset>
	</form>

</body>
</html>